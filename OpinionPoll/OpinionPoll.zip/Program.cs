﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Person person1 = new Person();
            List<Person> list = new List<Person>();
            for (int i = 0; i < n; i++)
            {
                string[] input = Console.ReadLine().Split();
                Person person = new Person(input[0], int.Parse(input[1]));
                list.Add(person);
            }

            person1.Print(list);
        }
    }
}
/*
5
Niki 33
Yord 88
Teo 22
Lily 44
Stan 11
 */
